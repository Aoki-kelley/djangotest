/*
Navicat MySQL Data Transfer

Source Server         : 1
Source Server Version : 80011
Source Host           : localhost:3306
Source Database       : userinfo

Target Server Type    : MYSQL
Target Server Version : 80011
File Encoding         : 65001

Date: 2021-11-07 23:45:53
*/

SET FOREIGN_KEY_CHECKS=0;
